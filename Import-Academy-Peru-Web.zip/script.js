const header = document.querySelector(".site-header");
const menuButton = document.querySelector(".menu-toggle");
const navLinks = document.querySelector(".nav-links");
const calculateButton = document.querySelector(".calculate-button");
const contactForm = document.querySelector(".contact-form");
const toast = document.querySelector(".toast");

window.addEventListener("scroll", () => {
  header.classList.toggle("scrolled", window.scrollY > 20);
});

menuButton.addEventListener("click", () => {
  const isOpen = navLinks.classList.toggle("open");
  menuButton.setAttribute("aria-expanded", String(isOpen));
  document.body.classList.toggle("menu-open", isOpen);
});

navLinks.querySelectorAll("a").forEach((link) => {
  link.addEventListener("click", () => {
    navLinks.classList.remove("open");
    menuButton.setAttribute("aria-expanded", "false");
    document.body.classList.remove("menu-open");
  });
});

function calculateImportCost() {
  const merchandise = Math.max(0, Number(document.querySelector("#merchandise").value) || 0);
  const shipping = Math.max(0, Number(document.querySelector("#shipping").value) || 0);
  const tariffRate = Number(document.querySelector("#tariff").value);
  const cifValue = merchandise + shipping;
  const tariff = cifValue * tariffRate;
  const vat = (cifValue + tariff) * 0.18;
  const total = cifValue + tariff + vat;

  document.querySelector("#totalCost").textContent = new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD"
  }).format(total);
}

calculateButton.addEventListener("click", calculateImportCost);
document.querySelectorAll(".calculator input, .calculator select").forEach((field) => {
  field.addEventListener("input", calculateImportCost);
});
calculateImportCost();

contactForm.addEventListener("submit", (event) => {
  event.preventDefault();
  toast.classList.add("show");
  contactForm.reset();
  window.setTimeout(() => toast.classList.remove("show"), 3500);
});

const observer = new IntersectionObserver((entries) => {
  entries.forEach((entry) => {
    if (entry.isIntersecting) {
      entry.target.classList.add("visible");
      observer.unobserve(entry.target);
    }
  });
}, { threshold: 0.12 });

document.querySelectorAll(".reveal").forEach((element) => observer.observe(element));
